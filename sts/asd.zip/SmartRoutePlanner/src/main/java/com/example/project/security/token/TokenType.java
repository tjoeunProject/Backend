package com.example.project.security.token;

public enum TokenType {
  BEARER
}
